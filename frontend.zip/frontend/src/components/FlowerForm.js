import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { createFlower, getFlower, updateFlower } from "../api";



const FlowerForm = () => {
  const [form, setForm] = useState({
    name: "",
    description: "",
    category: "",
    quantity: 0,
    status: "",
  });

  const navigate = useNavigate();
  const { id } = useParams();

  useEffect(() => {
    if (id) {
      getFlower(id).then(setForm).catch(console.error);
    }
  }, [id]);

  const handleChange = (e) =>
    setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (id) await updateFlower(id, form);
      else await createFlower(form);
      navigate("/flowers");
    } catch (err) {
      alert("Błąd zapisu");
    }
  };

  return (
    <div className="p-6 max-w-xl mx-auto bg-gray-50 min-h-screen">
      <h2 className="text-2xl font-bold text-green-700 mb-4">
        {id ? "✏️ Edytuj kwiat" : "➕ Dodaj nowy kwiat"}
      </h2>
      <form
        onSubmit={handleSubmit}
        className="bg-white p-6 rounded shadow-md space-y-4"
      >
        <input
          name="name"
          value={form.name}
          onChange={handleChange}
          placeholder="Nazwa kwiatu"
          className="w-full border px-4 py-2 rounded"
          required
        />

        <textarea
          name="description"
          value={form.description}
          onChange={handleChange}
          placeholder="Opis"
          className="w-full border px-4 py-2 rounded"
        />

        <input
          name="category"
          value={form.category}
          onChange={handleChange}
          placeholder="Kategoria"
          className="w-full border px-4 py-2 rounded"
        />

        <input
          type="number"
          name="quantity"
          value={form.quantity}
          onChange={handleChange}
          placeholder="Ilość"
          className="w-full border px-4 py-2 rounded"
        />

        <select
          name="status"
          value={form.status}
          onChange={handleChange}
          className="w-full border px-4 py-2 rounded"
        >
          <option value="">Wybierz status</option>
          <option value="Dostępny">Dostępny</option>
          <option value="Mało">Mało</option>
          <option value="Brak">Brak</option>
        </select>

        <button className="w-full bg-green-600 text-white py-2 rounded hover:bg-green-700">
          Zapisz
        </button>
      </form>
    </div>
  );
};

export default FlowerForm;
