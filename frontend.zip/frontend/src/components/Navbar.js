import React from "react";
import { Link } from "react-router-dom";

const Navbar = () => {
  return (
    <nav className="bg-white shadow-md px-6 py-4 flex justify-between items-center">
      <h1 className="text-xl font-bold text-green-700">🌸 Inwentaryzacja Kwiatów</h1>
      <div className="space-x-6 text-sm">
        <Link to="/" className="hover:underline">Strona główna</Link>
        <Link to="/login" className="hover:underline">Zaloguj</Link>
        <Link to="/register" className="hover:underline">Rejestracja</Link>
        <Link to="/flowers" className="hover:underline">Lista</Link>
        <Link to="/add" className="hover:underline">Dodaj</Link>
      </div>
    </nav>
  );
};

export default Navbar;
