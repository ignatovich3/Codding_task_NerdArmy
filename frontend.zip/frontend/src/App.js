import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import HomePage from './components/HomePage';
import Login from './components/Login';
import Register from './components/Register';
import FlowerList from './components/FlowerList';
import FlowerForm from './components/FlowerForm';
import './index.css'
import './styles.css'

const App = () => {
  return (
    <Router>
      <Navbar />
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/flowers" element={<FlowerList />} />
        <Route path="/add" element={<FlowerForm />} />
      </Routes>
    </Router>
  );
};

export default App;
